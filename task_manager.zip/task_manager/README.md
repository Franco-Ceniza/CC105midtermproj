Task Manager 📝✅
A simple task management web application built with Django.

🚀 Features
Create, update, and delete tasks
List all tasks
User-friendly UI with Bootstrap
Uses Django templates and static files
📌 Prerequisites
Ensure you have the following installed on your system:

Python (version 3.8 or higher)
pip (Python package manager)
Virtualenv (optional but recommended)
🛠 Setup Instructions
-cdtask_manager
-Create a Virtual Environment (Optional, Recommended)
python -m venv venv
Activate the virtual environment
-Install Dependencies

pip install -r requirements.txt
-Set Up the Database
Run migrations to set up the database:
python manage.py migrate
-Collect Static Files
python manage.py collectstatic --noinput
- Create a Superuser (for Admin Panel, Optional)
python manage.py createsuperuser
- Run the Development Server
python manage.py runserver
Visit http://127.0.0.1:8000/ in your browser to use the app.